﻿import fs from "fs/promises";
import path from "path";
import { JsonRpcProvider, Wallet, ContractFactory } from "ethers";

async function main() {
  const RPC = "http://127.0.0.1:8545";
  const provider = new JsonRpcProvider(RPC);

  const PRIVATE_KEY = process.env.PRIVATE_KEY;
  if (!PRIVATE_KEY) {
    throw new Error("Please set the PRIVATE_KEY environment variable to an account private key from the Hardhat node.");
  }
  const wallet = new Wallet(PRIVATE_KEY, provider);

  const artifactPath = path.resolve("artifacts/contracts/RigoBlockVuln.sol/RigoBlockVuln.json");
  const json = JSON.parse(await fs.readFile(artifactPath, "utf8"));

  // Deploy using ethers v6 API
  const factory = new ContractFactory(json.abi, json.bytecode, wallet);
  const contract = await factory.deploy();
  await contract.waitForDeployment(); // <- ethers v6

  console.log("Vulnerable Contract:", contract.target ?? contract.address);
}

main().catch((err) => {
  console.error("Error:", err);
  process.exit(1);
});
