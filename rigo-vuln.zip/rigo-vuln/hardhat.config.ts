import "@nomicfoundation/hardhat-ethers";

/** @type import("hardhat/config").HardhatUserConfig */
const config = {
  solidity: "0.8.20"
};

export default config;
